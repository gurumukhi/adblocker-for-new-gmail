# Cross browser add-on adfree-gmail
A cross browser add-on to remove all annoying Ads and Banners from Gmail (also supports new Gmail UI). Works well with Firefox & Chrome.

# Firefox listing link
https://addons.mozilla.org/en-US/firefox/addon/adfree-gmail/

# Description
* This add-on automatically hides all annoying ad banners from Gmail page.
* It works well on both old and new UI of Gmail.
* Enjoy seamless experience from this very light weight add-on very.
* This addon is completely safe to use as this addon removes ads from banner by double confirming that the add-on is not hiding any useful content accidentally.
* This is an open source project, find the code on https://github.com/gurumukhi/adblocker-for-new-gmail.

Support:
* Kindly feel free to open an issue on https://github.com/gurumukhi/adblocker-for-new-gmail/issues for any support.